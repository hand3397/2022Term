#pragma once
#include "GameObject.h"

//-------------------------------------------------------

const int PLAYER_WIDTH = 40;
const int PLAYER_HEIGHT = 60;

const int PLAYER_JUMP_POWER = 45;
const int PLAYER_SPEED = 10;

const int PLAYER_CONDITION_NULL = 0;
const int PLAYER_CONDITION_ONTHEFLOOR = 1;
const int PLAYER_CONDITION_FALLING = 2;
/*
	player condition
	0 = null
	1 = on the floor
	2 = falling, jump
*/
//-------------------------------------------------------

class Player : public Character
{
protected:
	bool doubleJump;
public:
	virtual void SetPlayer(int x, int y);
	int GetHeightSpeed() { return heightSpeed; }
	int GetSpeed() { return speed; }
	void SetPosX(int x);
	void SetPosY(int y);
	virtual void Move();
	virtual void Jump();
	virtual void Draw(HDC hdc);
};
//-------------------------------------------------------

void Player::SetPlayer(int x, int y)
{
	//set pos
	rect.left = x;
	rect.top = y;
	//set size
	rect.right = x + PLAYER_WIDTH;
	rect.bottom = y + PLAYER_HEIGHT;
	//set img
	img.Load(L"player_img.png");
	//set status
	speed = 0;
	condition = PLAYER_CONDITION_FALLING;
	doubleJump = true;
}

void Player::SetPosX(int x)
{
	rect.left = x;
	rect.right = x + PLAYER_WIDTH;
}

void Player::SetPosY(int y)
{
	rect.top = y;
	rect.bottom = y + PLAYER_HEIGHT;
}

void Player::Move()
{
	BOOL movingX = FALSE;

	if (condition == PLAYER_CONDITION_FALLING) {
		heightSpeed += GRAVITYACC;
		if (heightSpeed > TERMINALSPEED)
			heightSpeed = TERMINALSPEED;
	}
	else if (condition == PLAYER_CONDITION_ONTHEFLOOR){
		doubleJump = true;
		heightSpeed = 0;
	}

	rect.left += speed;
	rect.right += speed;
	rect.top += heightSpeed;
	rect.bottom += heightSpeed;
}

void Player::Jump()
{
	if (condition == PLAYER_CONDITION_FALLING) {
		if (doubleJump)
 			doubleJump = false;
		else
			return;
	}

	condition = PLAYER_CONDITION_FALLING;
	heightSpeed = -PLAYER_JUMP_POWER;
}

void Player::Draw(HDC hdc)
{
	img.Draw(hdc, rect.left, rect.top, PLAYER_WIDTH, PLAYER_HEIGHT);
}