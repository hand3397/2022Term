#pragma once
#include <vector>
#include "Player.h"
#include "Enemy.h"

using namespace std;

//-------------------------------------------------------

class Stage;

//-------------------------------------------------------

class Stage
{
protected:
	bool jumpKeyUp = true;
	int objectCnt = 0;
	int characterCnt = 0;
	Player* player;
	vector <Object*> objects;
	vector <Character*> characters;
public:
	void SetStage_Test();
	void DrawStage(HDC hdc);
	void CreatePlayer(int x, int y);
	void CreateWall(int x, int y, int width, int height);
	void Update();
	void SetPlayerCondition();
	void ControlManager_KeyDown();
};

//-------------------------------------------------------

void Stage::CreatePlayer(int x, int y)
{
	player = new Player;
	player->SetPlayer(x, y);
}

void Stage::DrawStage(HDC hdc)
{
	for (int i = 0; i < objectCnt; ++i)
		if (objects[i] != nullptr)
			objects[i]->Draw(hdc);

	if (player != nullptr)
		player->Draw(hdc);
}

void Stage::SetStage_Test()
{
	CreatePlayer(100, 100);
	CreateWall(0, 600, 600, 100);
	CreateWall(300, 500, 100, 200);
	CreateWall(250, 200, 200, 100);
}

void Stage::CreateWall(int x, int y, int width, int height)
{
	Object* wall = new Object;
	wall->SetRect(x, y, width, height);
	objects.push_back(wall);
	++objectCnt;
}

void Stage::SetPlayerCondition()
{
	if (player == nullptr) return;

	RECT tmpRect;
	RECT playerRect = player->GetRect();
	RECT objectRect;

	BOOL changeCondition = false;

	for (int i = 0; i < objectCnt; ++i)
		if (objects[i] != nullptr) {
			objectRect = objects[i]->GetRect();

			if (IntersectRect(&tmpRect, &playerRect, &objectRect)) {
				int tmpRectW = abs(tmpRect.right - tmpRect.left);
				int tmpRectH = abs(tmpRect.bottom - tmpRect.top);

				if (tmpRectH - 20 < tmpRectW) {
					//Intersect Top
					if (tmpRect.top == player->GetRect().top) {
						player->SetPosY(objectRect.bottom);
						player->SetHeightSpeed(0);
					}
					//Intersect Bottom
					else if (tmpRect.bottom == player->GetRect().bottom) {
						player->SetPosY(objectRect.top - PLAYER_HEIGHT);
						player->SetCondition(PLAYER_CONDITION_ONTHEFLOOR);
						changeCondition = true;
					}
				}
				else {
					//Intersect Right
					if (tmpRect.right == player->GetRect().right) {
						player->SetPosX(objectRect.left - PLAYER_WIDTH);
					}
					//Intersect Left
					else if (tmpRect.left == player->GetRect().left) {
						player->SetPosX(objectRect.right);
					}
				}
			}
		}

	if(!changeCondition)
		player->SetCondition(PLAYER_CONDITION_FALLING);
}

void Stage::Update()
{
	if (player != nullptr)
		player->Move();

	for (int i = 0; i < characterCnt; ++i)
		if (characters[i] != nullptr)
			characters[i]->Move();

	SetPlayerCondition();
}

void Stage::ControlManager_KeyDown()
{
	BOOL movingX = false;
	if (GetAsyncKeyState(VK_RIGHT) & 0x8000) {
		player->SetSpeed(PLAYER_SPEED);
		movingX = TRUE;
	}
	if (GetAsyncKeyState(VK_LEFT) & 0x8000) {
		player->SetSpeed(-PLAYER_SPEED);
		movingX = TRUE;
	}
	if (GetAsyncKeyState(VK_SPACE) & 0x0001){
		player->Jump();
	}
	if (!movingX) {
		player->SetSpeed(0);
	}
}