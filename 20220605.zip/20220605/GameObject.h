#pragma once
#define _USE_MATH_DEFINES

#include <atlImage.h>
#include <cmath>

using namespace std;

//--------------------------------------------------------------------

const int TERMINALSPEED = 25;
const int GRAVITYACC = 5;

struct Point;
class Object;
class Character;

//--------------------------------------------------------------------

struct Point
{
	int x;
	int y;
};

class Object
{
protected:
	CImage img;
	RECT rect;
public:
	RECT GetRect() { return rect; }
	void SetRect(int x, int y, int width, int height);
	void SetPosX(int x);
	void SetPosY(int y);
	virtual void Draw(HDC hdc);
};

class Character : protected Object
{
protected:
	int iSee;
	int hp;
	int attackPower;
	int speed;
	int heightSpeed = 0;
	int condition;
public:
	void SetHeightSpeed(int speed) { heightSpeed = speed; }
	void SetSpeed(int speed) { this->speed = speed; }
	RECT GetRect() { return rect; }
	virtual void Move() {}
	virtual void SetCondition(int condition) { this->condition = condition; }
};

//--------------------------------------------------------------------

void Object::SetRect(int x, int y, int width, int height)
{
	rect.left = x;
	rect.top = y;
	rect.right = x + width;
	rect.bottom = y + height;
}

void Object::SetPosX(int x)
{
	rect.left = x;
}

void Object::SetPosY(int y)
{
	rect.top = y;
}

void Object::Draw(HDC hdc)
{
	HPEN hpen, oldpen;
	hpen = CreatePen(BS_SOLID, 1, RGB(255, 255, 255));
	oldpen = (HPEN)SelectObject(hdc, hpen);

	Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);

	SelectObject(hdc, oldpen);
	DeleteObject(hpen);
}

//--------------------------------------------------------------------
