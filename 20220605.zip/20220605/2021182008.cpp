#define _USE_MATH_DEFINES

#include <windows.h>
#include <random>
#include <ctime>
#include "Stage.h"

HINSTANCE g_hInst;
LPCTSTR lpszClass = L"2021182008";
LPCTSTR lpszWindowName = L"Window Programming Lab";
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

void CALLBACK GameUpdate(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);

//-------------
Stage* stage = new Stage;
//-------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASSEX WndClass;
	g_hInst = hInstance;
	WndClass.cbSize = sizeof(WndClass);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	WndClass.lpszMenuName = NULL;
	WndClass.lpszClassName = lpszClass;
	WndClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	RegisterClassEx(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszWindowName, WS_OVERLAPPEDWINDOW, 0, 0, 1000, 800, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	while (GetMessage(&Message, 0, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	RECT clientRect;
	PAINTSTRUCT ps;
	static HDC hdc, memdc;
	static HBITMAP hBitmap;
	static CImage backimg;

	switch (uMsg) {
	case WM_CREATE:
		srand(time(0));
		stage->SetStage_Test();
		SetTimer(hWnd, 1, 33, GameUpdate);
		break;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &clientRect);
		hBitmap = CreateCompatibleBitmap(hdc, clientRect.right, clientRect.bottom);
		memdc = CreateCompatibleDC(hdc);
		(HBITMAP)SelectObject(memdc, hBitmap);

		stage->DrawStage(memdc);
		
		BitBlt(hdc, 0, 0, clientRect.right, clientRect.bottom, memdc, 0, 0, SRCCOPY);

		DeleteObject(hBitmap);
		DeleteDC(memdc);
		EndPaint(hWnd, &ps);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void CALLBACK GameUpdate(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	stage->ControlManager_KeyDown();
	stage->Update();
	InvalidateRect(hWnd, NULL, FALSE);
}
